

<?php $__env->startSection('title','Edit User'); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold mb-6">Edit User</h1>

  <?php if(session('success')): ?>
    <div class="bg-green-100 text-green-800 border border-green-300 p-3 rounded mb-4"><?php echo e(session('success')); ?></div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
    <div class="bg-red-100 border border-red-300 text-red-800 px-4 py-3 rounded mb-4">
      <ul class="list-disc ml-5">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($e); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST" class="space-y-5 max-w-2xl">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <label class="block mb-1 font-medium">Nama</label>
        <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" class="w-full border rounded px-3 py-2" required>
      </div>
      <div>
        <label class="block mb-1 font-medium">Email</label>
        <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" class="w-full border rounded px-3 py-2" required>
      </div>
      <div>
        <label class="block mb-1 font-medium">NIM</label>
        <input type="text" name="nim" value="<?php echo e(old('nim', optional($user->profile)->nim)); ?>" class="w-full border rounded px-3 py-2">
      </div>
      <div>
        <label class="block mb-1 font-medium">Program Studi</label>
        <input type="text" name="program_studi" value="<?php echo e(old('program_studi', optional($user->profile)->program_studi)); ?>" class="w-full border rounded px-3 py-2">
      </div>
      <div>
        <label class="block mb-1 font-medium">Asal Kampus</label>
        <input type="text" name="kampus" value="<?php echo e(old('kampus', optional($user->profile)->kampus)); ?>" class="w-full border rounded px-3 py-2">
      </div>
      <div>
        <label class="block mb-1 font-medium">Tahun Ajaran</label>
        <input type="text" name="tahun_ajaran" value="<?php echo e(old('tahun_ajaran', optional($user->profile)->tahun_ajaran)); ?>" class="w-full border rounded px-3 py-2">
      </div>
    </div>

    <div class="pt-2 flex gap-3">
      <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Simpan</button>
      <a href="<?php echo e(route('admin.users.index')); ?>" class="px-4 py-2 rounded border">Batal</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\webpenelitian\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>