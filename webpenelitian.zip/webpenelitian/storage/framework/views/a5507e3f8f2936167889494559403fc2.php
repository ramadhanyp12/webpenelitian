

<?php $__env->startSection('title', 'Ubah Password'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold mb-4">Ubah Password</h1>

    
    <?php if(session('status')): ?>
        <div style="background:#e6ffed;border:1px solid #34d399;color:#065f46;padding:.75rem 1rem;margin-bottom:1rem;">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    
    <?php if($errors->any()): ?>
        <div style="background:#fee2e2;border:1px solid #ef4444;color:#991b1b;padding:.75rem 1rem;margin-bottom:1rem;">
            <ul style="margin-left:1rem;list-style:disc;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($e); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('password.update')); ?>" class="space-y-4" style="max-width:520px">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label class="block mb-1 font-medium">Password Lama</label>
            <input type="password" name="current_password"
                   class="w-full border rounded px-3 py-2"
                   required>
            <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="block mb-1 font-medium">Password Baru</label>
            <input type="password" name="password"
                   class="w-full border rounded px-3 py-2"
                   required>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="block mb-1 font-medium">Konfirmasi Password Baru</label>
            <input type="password" name="password_confirmation"
                   class="w-full border rounded px-3 py-2"
                   required>
            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">
            Ubah Password
        </button>
    </form>

    
    <?php if($errors->any()): ?>
        <script>
            alert(`Error:\n<?php echo implode("\n", $errors->all()); ?>`);
        </script>
    <?php endif; ?>

    
    <?php if(session('error')): ?>
        <script>
            alert("<?php echo e(session('error')); ?>");
        </script>
    <?php endif; ?>

    
    <?php if(session('status')): ?>
        <script>
            alert("<?php echo e(session('status')); ?>");
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\webpenelitian\resources\views/profile/password.blade.php ENDPATH**/ ?>