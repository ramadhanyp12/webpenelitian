

<?php $__env->startSection('title','Daftar Approvals'); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold mb-6">Approvals</h1>

  <?php if(session('success')): ?>
    <div class="bg-green-100 text-green-800 border border-green-300 p-3 rounded mb-4"><?php echo e(session('success')); ?></div>
  <?php endif; ?>

  
  <div class="mb-8">
    <h2 class="font-semibold text-lg mb-2">Menunggu Persetujuan</h2>
    <div class="bg-white shadow rounded overflow-x-auto">
      <table class="min-w-full border">
        <thead class="bg-gray-100">
          <tr>
            <th class="px-4 py-2 border">#</th>
            <th class="px-4 py-2 border">User</th>
            <th class="px-4 py-2 border">Judul</th>
            <th class="px-4 py-2 border">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $waiting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td class="px-4 py-2 border align-top"><?php echo e($loop->iteration); ?></td>
              <td class="px-4 py-2 border align-top"><?php echo e($t->user->name); ?></td>
              <td class="px-4 py-2 border align-top"><?php echo e($t->judul_penelitian); ?></td>
              <td class="px-4 py-2 border">
                <div class="flex flex-wrap items-center gap-2">
                  
                  <a href="<?php echo e(route('admin.approvals.create', $t->id)); ?>"
                     class="px-3 py-1 bg-blue-600 text-white rounded">Isi Data Persetujuan</a>

                  
                  <form class="inline" action="<?php echo e(route('admin.approvals.deny', $t->id)); ?>" method="POST"
                        onsubmit="return confirm('Tolak tiket ini dengan alasan default?');">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="alasan_ditolak" value="Data belum lengkap.">
                    <button type="submit" class="px-3 py-1 bg-red-600 text-white rounded">Tolak cepat</button>
                  </form>

                  
                  <details class="w-full mt-2">
                    <summary class="cursor-pointer select-none text-red-700 hover:underline">
                      Tolak dengan alasan sendiri
                    </summary>
                    <form class="mt-2" action="<?php echo e(route('admin.approvals.deny', $t->id)); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                      <textarea name="alasan_ditolak" rows="2" class="w-full border rounded px-3 py-2"
                                placeholder="Tulis alasan penolakan" required></textarea>
                      <div class="mt-2">
                        <button class="px-3 py-1 bg-red-700 text-white rounded">Kirim Penolakan</button>
                      </div>
                    </form>
                  </details>
                </div>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="4" class="px-4 py-3 text-center text-gray-500">Tidak ada</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  
  <div>
    <h2 class="font-semibold text-lg mb-2">Approval Tersimpan</h2>
    <div class="bg-white shadow rounded overflow-x-auto">
      <table class="min-w-full border">
        <thead class="bg-gray-100">
          <tr>
            <th class="px-4 py-2 border">#</th>
            <th class="px-4 py-2 border">User</th>
            <th class="px-4 py-2 border">No. Surat</th>
            <th class="px-4 py-2 border">Judul</th>
            <th class="px-4 py-2 border">PDF</th>
            <th class="px-4 py-2 border">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $approvals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td class="px-4 py-2 border"><?php echo e($approvals->firstItem() + $loop->index); ?></td>
              <td class="px-4 py-2 border"><?php echo e($a->ticket->user->name ?? '-'); ?></td>
              <td class="px-4 py-2 border"><?php echo e($a->nomor_surat); ?></td>
              <td class="px-4 py-2 border"><?php echo e($a->judul_penelitian); ?></td>
              <td class="px-4 py-2 border">
                <?php if($a->generated_pdf_path): ?>
                  <a href="<?php echo e(asset('storage/'.$a->generated_pdf_path)); ?>" target="_blank" class="text-blue-600 underline">Lihat PDF</a>
                <?php else: ?>
                  <span class="text-gray-500">-</span>
                <?php endif; ?>
              </td>
              <td class="px-4 py-2 border">
                <div class="flex flex-wrap items-center gap-2">
                  <a href="<?php echo e(route('admin.approvals.edit', $a->id)); ?>" class="text-yellow-600">Edit</a>

                  <form class="inline" action="<?php echo e(route('admin.approvals.generatePdf', $a->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="px-3 py-1 bg-indigo-600 text-white rounded">Generate PDF</button>
                  </form>

                  
<?php if($a->generated_pdf_path): ?>
  <a href="<?php echo e(route('admin.approvals.release', $a->id)); ?>"
     class="px-3 py-1 bg-green-600 text-white rounded">
     Upload Signed
  </a>
<?php endif; ?>

                  
                  <details class="w-full">
                    <summary class="cursor-pointer select-none text-red-700 hover:underline">
                      Tolak tiket ini (ubah status + alasan)
                    </summary>
                    <form class="mt-2" action="<?php echo e(route('admin.approvals.deny', $a->ticket_id)); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                      <textarea name="alasan_ditolak" rows="2" class="w-full border rounded px-3 py-2"
                                placeholder="Tulis alasan penolakan" required></textarea>
                      <div class="mt-2">
                        <button class="px-3 py-1 bg-red-700 text-white rounded">Kirim Penolakan</button>
                      </div>
                    </form>
                  </details>
                </div>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6" class="px-4 py-3 text-center text-gray-500">Belum ada approval</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
      <div class="px-3 py-3">
  <?php echo e($approvals->withQueryString()->links()); ?>

</div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\webpenelitian\resources\views/admin/approvals/index.blade.php ENDPATH**/ ?>