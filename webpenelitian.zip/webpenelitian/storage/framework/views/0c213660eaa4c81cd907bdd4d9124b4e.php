

<?php $__env->startSection('title','Data User'); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold mb-6">Data User</h1>
  <form method="GET" action="<?php echo e(route('admin.users.index')); ?>" class="mb-4 flex items-center gap-2">
  <input type="text"
         name="q"
         value="<?php echo e($q ?? ''); ?>"
         placeholder="Cari nama, email, atau kampus…"
         class="border rounded px-3 py-2 w-72">
  <button class="px-4 py-2 bg-blue-600 text-white rounded">Cari</button>

  <?php if(!empty($q)): ?>
    <a href="<?php echo e(route('admin.users.index')); ?>" class="px-3 py-2 border rounded">Reset</a>
  <?php endif; ?>
</form>

  <?php if(session('success')): ?>
    <div class="bg-green-100 text-green-800 border border-green-300 p-3 rounded mb-4"><?php echo e(session('success')); ?></div>
  <?php endif; ?>

  <div class="overflow-x-auto bg-white shadow rounded">
    <table class="min-w-full border border-gray-300">
      <thead class="bg-gray-100">
        <tr>
          <th class="px-4 py-2 border">#</th>
          <th class="px-4 py-2 border">Nama</th>
          <th class="px-4 py-2 border">Email</th>
          <th class="px-4 py-2 border">Asal Kampus</th>
          <th class="px-4 py-2 border">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="border-t">
            <td class="px-4 py-2 border"><?php echo e(($users->currentPage()-1)*$users->perPage() + $loop->iteration); ?></td>
            <td class="px-4 py-2 border"><?php echo e($u->name); ?></td>
            <td class="px-4 py-2 border"><?php echo e($u->email); ?></td>
            <td class="px-4 py-2 border"><?php echo e($u->profile->kampus ?? '-'); ?></td>
            <td class="px-4 py-2 border space-x-2">
              <a href="<?php echo e(route('admin.users.show', $u->id)); ?>" class="text-blue-600">Lihat</a> |
              <a href="<?php echo e(route('admin.users.edit', $u->id)); ?>" class="text-yellow-600">Edit</a>
              <?php if($u->role !== 'admin'): ?>
    <span class="mx-1">|</span>
    <form action="<?php echo e(route('admin.users.destroy', $u->id)); ?>"
          method="POST"
          class="inline"
          onsubmit="return confirm('Hapus user ini BESERTA seluruh tiket, approval, dan dokumennya?');">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button type="submit" class="text-red-600 hover:underline">Hapus</button>
    </form>
  <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="5" class="px-4 py-6 text-center text-gray-500">Belum ada user</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <div class="mt-4">
    <?php echo e($users->links()); ?>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\webpenelitian\resources\views/admin/users/index.blade.php ENDPATH**/ ?>