

<?php $__env->startSection('title', 'Tambah Ticket (Admin)'); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold mb-6">Tambah Ticket</h1>

  <?php if($errors->any()): ?>
    <div class="bg-red-100 border border-red-300 text-red-800 px-4 py-3 rounded mb-4">
      <ul class="list-disc ml-5">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($e); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  <form action="<?php echo e(route('admin.tickets.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-5 max-w-xl">
    <?php echo csrf_field(); ?>

    <div>
      <label class="block mb-1 font-medium">Nama</label>
      <input type="text" name="nama" value="<?php echo e(old('nama', $prefill['nama'] ?? '')); ?>" class="w-full border rounded px-3 py-2" required>
    </div>

    <div>
      <label class="block mb-1 font-medium">NIM</label>
      <input type="text" name="nim" value="<?php echo e(old('nim', $prefill['nim'] ?? '')); ?>" class="w-full border rounded px-3 py-2" required>
    </div>

    <div>
      <label class="block mb-1 font-medium">Program Studi</label>
      <input type="text" name="program_studi" value="<?php echo e(old('program_studi', $prefill['program_studi'] ?? '')); ?>" class="w-full border rounded px-3 py-2" required>
    </div>

    <div>
      <label class="block mb-1 font-medium">Asal Kampus</label>
      <input type="text" name="kampus" value="<?php echo e(old('kampus', $prefill['kampus'] ?? '')); ?>" class="w-full border rounded px-3 py-2" required>
    </div>

    <div>
      <label class="block mb-1 font-medium">Tahun Ajaran</label>
      <input type="text" name="tahun_ajaran" value="<?php echo e(old('tahun_ajaran', $prefill['tahun_ajaran'] ?? '')); ?>" class="w-full border rounded px-3 py-2" required>
    </div>

    <div>
      <label class="block mb-1 font-medium">Judul Penelitian</label>
      <input type="text" name="judul_penelitian" value="<?php echo e(old('judul_penelitian')); ?>" class="w-full border rounded px-3 py-2" required>
    </div>
    <?php $__errorArgs = ['judul_penelitian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-red-600 text-sm -mt-3"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div>
      <label class="block mb-1 font-medium">Keterangan (File yang diminta apa saja tulis disini)</label>
      <textarea name="keterangan" rows="3" class="w-full border rounded px-3 py-2" placeholder="Opsional"><?php echo e(old('keterangan')); ?></textarea>
    </div>

    <div>
      <label for="lokasi_pengadilan" class="block mb-1 font-medium">Lokasi Pengadilan</label>
      <select name="lokasi_pengadilan" id="lokasi_pengadilan" class="w-full border rounded px-3 py-2">
        <?php
          $opsi = ['PTA Gorontalo','PA Gorontalo','PA Suwawa','PA Limboto','PA Tilamuta','PA Kwandang','PA Marisa'];
          $selected = old('lokasi_pengadilan', $prefill['lokasi_pengadilan'] ?? 'PTA Gorontalo');
        ?>
        <?php $__currentLoopData = $opsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($op); ?>" <?php echo e($selected === $op ? 'selected' : ''); ?>><?php echo e($op); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div>
      <label class="block mb-1 font-medium">Upload Surat (PDF, bisa banyak, max 20MB/file)</label>
      <input type="file" name="surat_files[]" accept="application/pdf" class="w-full border rounded px-3 py-2" multiple>
      <p class="text-xs text-gray-500 mt-1">Kamu bisa memilih beberapa file sekaligus.</p>
    </div>

    <div>
      <label class="block mb-1 font-medium">Upload Lampiran (PDF, opsional, bisa banyak, max 20MB/file)</label>
      <input type="file" name="lampiran_files[]" accept="application/pdf" class="w-full border rounded px-3 py-2" multiple>
    </div>

    <div class="pt-2 flex gap-3">
      <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Simpan Ticket</button>
      <a href="<?php echo e(route('admin.tickets.index')); ?>" class="px-4 py-2 rounded border">Batal</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\webpenelitian\resources\views/admin/tickets/create.blade.php ENDPATH**/ ?>