

<?php $__env->startSection('title', 'Edit Ticket #'.$ticket->id); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold mb-6">Edit Ticket #<?php echo e($ticket->id); ?></h1>

  <?php if($errors->any()): ?>
    <div class="bg-red-100 border border-red-300 text-red-800 px-4 py-3 rounded mb-4">
      <ul class="list-disc ml-5">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($e); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  <form action="<?php echo e(route('tickets.update', $ticket->id)); ?>"
        method="POST"
        enctype="multipart/form-data"
        class="space-y-5 max-w-xl">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div>
      <label class="block mb-1 font-medium">Nama</label>
      <input type="text" name="nama" value="<?php echo e(old('nama', $ticket->nama)); ?>" class="w-full border rounded px-3 py-2" required>
      <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
      <label class="block mb-1 font-medium">NIM</label>
      <input type="text" name="nim" value="<?php echo e(old('nim', $ticket->nim)); ?>" class="w-full border rounded px-3 py-2" required>
      <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
      <label class="block mb-1 font-medium">Program Studi</label>
      <input type="text" name="program_studi" value="<?php echo e(old('program_studi', $ticket->program_studi)); ?>" class="w-full border rounded px-3 py-2" required>
      <?php $__errorArgs = ['program_studi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
      <label class="block mb-1 font-medium">Asal Kampus</label>
      <input type="text" name="kampus" value="<?php echo e(old('kampus', $ticket->kampus)); ?>" class="w-full border rounded px-3 py-2" required>
      <?php $__errorArgs = ['kampus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
      <label class="block mb-1 font-medium">Tahun Ajaran</label>
      <input type="text" name="tahun_ajaran" value="<?php echo e(old('tahun_ajaran', $ticket->tahun_ajaran)); ?>" class="w-full border rounded px-3 py-2" required>
      <?php $__errorArgs = ['tahun_ajaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
      <label class="block mb-1 font-medium">Judul Penelitian</label>
      <input type="text" name="judul_penelitian" value="<?php echo e(old('judul_penelitian', $ticket->judul_penelitian)); ?>" class="w-full border rounded px-3 py-2" required>
      <?php $__errorArgs = ['judul_penelitian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
      <label class="block mb-1 font-medium">Keterangan (File yang diminta apa saja tulis di sini)</label>
      <textarea name="keterangan" rows="3" class="w-full border rounded px-3 py-2"><?php echo e(old('keterangan', $ticket->keterangan)); ?></textarea>
      <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
      <label for="lokasi_pengadilan" class="block mb-1 font-medium">Lokasi Pengadilan</label>
      <?php
        $lok = old('lokasi_pengadilan', $ticket->lokasi_pengadilan);
      ?>
      <select name="lokasi_pengadilan" id="lokasi_pengadilan" class="w-full border rounded px-3 py-2">
          <option value="PTA Gorontalo" <?php echo e($lok==='PTA Gorontalo' ? 'selected' : ''); ?>>PTA Gorontalo</option>
          <option value="PA Gorontalo"  <?php echo e($lok==='PA Gorontalo'  ? 'selected' : ''); ?>>PA Gorontalo</option>
          <option value="PA Suwawa"    <?php echo e($lok==='PA Suwawa'    ? 'selected' : ''); ?>>PA Suwawa</option>
          <option value="PA Limboto"   <?php echo e($lok==='PA Limboto'   ? 'selected' : ''); ?>>PA Limboto</option>
          <option value="PA Tilamuta"  <?php echo e($lok==='PA Tilamuta'  ? 'selected' : ''); ?>>PA Tilamuta</option>
          <option value="PA Kwandang"  <?php echo e($lok==='PA Kwandang'  ? 'selected' : ''); ?>>PA Kwandang</option>
          <option value="PA Marisa"    <?php echo e($lok==='PA Marisa'    ? 'selected' : ''); ?>>PA Marisa</option>
      </select>
      <?php $__errorArgs = ['lokasi_pengadilan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="border rounded p-3 mb-4">
      <div class="font-semibold mb-2">Surat permohonan saat ini (<?php echo e($ticket->suratDocuments->count()); ?>)</div>
      <?php if($ticket->suratDocuments->count()): ?>
        <ul class="list-disc ml-5 space-y-1">
          <?php $__currentLoopData = $ticket->suratDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="flex items-center gap-2">
              <a href="<?php echo e(asset('storage/'.$doc->file_path)); ?>" target="_blank" class="text-blue-600 underline">
                <?php echo e($doc->original_name ?? basename($doc->file_path)); ?>

              </a>
              <button type="submit"
                      form="del-surat-<?php echo e($doc->id); ?>"
                      class="text-red-600 hover:underline text-sm"
                      onclick="return confirm('Hapus dokumen ini?')">
                Hapus
              </button>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      <?php else: ?>
        <div class="text-sm text-gray-500">Belum ada file.</div>
      <?php endif; ?>
    </div>

    
    <div class="border rounded p-3 mb-4">
      <div class="font-semibold mb-2">Lampiran permohonan saat ini (<?php echo e($ticket->lampiranDocuments->count()); ?>)</div>
      <?php if($ticket->lampiranDocuments->count()): ?>
        <ul class="list-disc ml-5 space-y-1">
          <?php $__currentLoopData = $ticket->lampiranDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="flex items-center gap-2">
              <a href="<?php echo e(asset('storage/'.$doc->file_path)); ?>" target="_blank" class="text-blue-600 underline">
                <?php echo e($doc->original_name ?? basename($doc->file_path)); ?>

              </a>
              <button type="submit"
                      form="del-lampiran-<?php echo e($doc->id); ?>"
                      class="text-red-600 hover:underline text-sm"
                      onclick="return confirm('Hapus dokumen ini?')">
                Hapus
              </button>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      <?php else: ?>
        <div class="text-sm text-gray-500">Belum ada file.</div>
      <?php endif; ?>
    </div>

    
    <div>
      <label class="block mb-1 font-medium">Tambah Surat permohonan baru (PDF, max 20MB/file)</label>
      <input type="file" name="surat_files[]" accept="application/pdf" class="w-full border rounded px-3 py-2" multiple>
      <?php $__errorArgs = ['surat_files.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
      <label class="block mb-1 font-medium">Tambah Lampiran permohonan baru (PDF, max 20MB/file)</label>
      <input type="file" name="lampiran_files[]" accept="application/pdf" class="w-full border rounded px-3 py-2" multiple>
      <?php $__errorArgs = ['lampiran_files.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="pt-2 flex gap-3">
      <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Simpan Perubahan</button>
      <a href="<?php echo e(route('tickets.index')); ?>" class="px-4 py-2 rounded border">Batal</a>
    </div>
  </form>

  
  <?php $__currentLoopData = $ticket->suratDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form id="del-surat-<?php echo e($doc->id); ?>"
          action="<?php echo e(route('tickets.documents.destroy', [$ticket->id, $doc->id])); ?>"
          method="POST" style="display:none;">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
    </form>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
  <?php $__currentLoopData = $ticket->lampiranDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form id="del-lampiran-<?php echo e($doc->id); ?>"
          action="<?php echo e(route('tickets.documents.destroy', [$ticket->id, $doc->id])); ?>"
          method="POST" style="display:none;">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
    </form>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\webpenelitian\resources\views/tickets/edit.blade.php ENDPATH**/ ?>