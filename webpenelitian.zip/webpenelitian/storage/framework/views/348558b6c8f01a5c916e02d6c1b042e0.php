

<?php $__env->startSection('title', 'Daftar Tickets (Admin)'); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold mb-6">Daftar Tickets</h1>

  <?php if(session('success')): ?>
    <div class="bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded mb-4">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>

  <div class="mb-4 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
  <a href="<?php echo e(route('admin.tickets.create')); ?>" class="bg-green-600 text-white px-4 py-2 rounded">
    + Buat Ticket
  </a>

  <form action="<?php echo e(route('admin.tickets.index')); ?>" method="GET" class="flex items-center gap-2">
    <input type="text" name="q" value="<?php echo e($q ?? ''); ?>" placeholder="Cari nama user / judul / NIM"
           class="border rounded px-3 py-2 w-72" />
    <?php if(!empty($q)): ?>
      <a href="<?php echo e(route('admin.tickets.index')); ?>" class="text-gray-600 underline">Reset</a>
    <?php endif; ?>
    <button class="px-3 py-2 bg-blue-600 text-white rounded">Cari</button>
  </form>
</div>

  <div class="overflow-x-auto bg-white shadow rounded">
    <table class="min-w-full border border-gray-300">
      <thead class="bg-gray-100">
        <tr>
          <th class="px-4 py-2 border">#</th>
          <th class="px-4 py-2 border">User</th>
          <th class="px-4 py-2 border">Judul</th>
          <th class="px-4 py-2 border">Status</th>
          
          <th class="px-4 py-2 border">Surat Permohonan</th>
          <th class="px-4 py-2 border">Lampiran Permohonan</th>
          <th class="px-4 py-2 border">Surat Izin</th>
          <th class="px-4 py-2 border">Hasil Penelitian</th>
          <th class="px-4 py-2 border">Aksi</th>
        </tr>
      </thead>

      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="border-t align-top">
            <td class="px-4 py-2 border"><?php echo e(($tickets->firstItem() ?? 1) + $loop->index); ?></td>
            <td class="px-4 py-2 border"><?php echo e($t->user->name); ?></td>
            <td class="px-4 py-2 border"><?php echo e($t->judul_penelitian); ?></td>

            
            <td class="px-4 py-2 border">
              <?php if($t->status === 'ditolak' && filled($t->alasan_ditolak)): ?>
                <span class="inline-block rounded border border-red-300 bg-red-50 text-red-700 text-xs px-2 py-1">
                  Ditolak: <?php echo e($t->alasan_ditolak); ?>

                </span>
              <?php else: ?>
                <?php
                  $classes = [
                    'dikirim'                => 'bg-gray-100 text-gray-700',
                    'menunggu_persetujuan'   => 'bg-yellow-100 text-yellow-700',
                    'disetujui'              => 'bg-blue-100 text-blue-700',
                    'ditolak'                => 'bg-red-100 text-red-700',
                    'menunggu_hasil'         => 'bg-amber-100 text-amber-700',
                    'selesai'                => 'bg-green-100 text-green-700',
                  ];
                ?>
                <span class="px-2 py-1 rounded text-sm <?php echo e($classes[$t->status] ?? 'bg-gray-100 text-gray-700'); ?>">
                  <?php echo e($t->status); ?>

                </span>
              <?php endif; ?>
            </td>

            
            <td class="px-4 py-2 border">
              <?php $surats = $t->suratDocuments ?? collect(); ?>
              <?php if($surats->count()): ?>
                <?php $__currentLoopData = $surats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div>
                    <a href="<?php echo e(asset('storage/'.$doc->file_path)); ?>" target="_blank" class="text-blue-600 underline">
                      <?php echo e($doc->original_name); ?>

                    </a>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
                <span class="text-gray-500">-</span>
              <?php endif; ?>
            </td>

            
            <td class="px-4 py-2 border">
              <?php $lampirans = $t->lampiranDocuments ?? collect(); ?>
              <?php if($lampirans->count()): ?>
                <?php $__currentLoopData = $lampirans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div>
                    <a href="<?php echo e(asset('storage/'.$doc->file_path)); ?>" target="_blank" class="text-blue-600 underline">
                      <?php echo e($doc->original_name); ?>

                    </a>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
                <span class="text-gray-500">-</span>
              <?php endif; ?>
            </td>

 
<td class="px-4 py-2 border">
  <?php
    // tentukan path & kolom sumber (baru vs lama)
    $suratIzinPath = $t->surat_izin_pdf_path ?: $t->hasil_pdf_path;
    $suratIzinCol  = $t->surat_izin_pdf_path ? 'surat_izin_pdf_path'
                  : ($t->hasil_pdf_path     ? 'hasil_pdf_path'       : null);
  ?>

  <?php if($suratIzinPath): ?>
    <div class="flex items-center gap-2">
      <a href="<?php echo e(asset('storage/'.$suratIzinPath)); ?>" target="_blank" class="text-blue-600 underline">
        Surat Izin
      </a>

      
      <form action="<?php echo e(route('admin.tickets.suratizin.destroy', $t->id)); ?>"
            method="POST" class="inline"
            onsubmit="return confirm('Hapus file Surat Izin ini?');">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <input type="hidden" name="col" value="<?php echo e($suratIzinCol); ?>">
        <button type="submit" class="text-red-600 hover:underline">Hapus</button>
      </form>
    </div>
  <?php else: ?>
    <span class="text-gray-500">Belum ada</span>
  <?php endif; ?>
</td>

            
            <td class="px-4 py-2 border">
              <?php if($t->hasil_penelitian_path): ?>
                <a href="<?php echo e(asset('storage/'.$t->hasil_penelitian_path)); ?>" target="_blank" class="text-blue-600 underline">
                  Hasil
                </a>

                
                <form action="<?php echo e(route('admin.tickets.hasil.destroy', $t)); ?>" method="POST"
                      onsubmit="return confirm('Hapus file hasil penelitian?')" class="inline-block ml-2">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button class="text-red-600 underline text-sm">Hapus</button>
                </form>
              <?php else: ?>
                <span class="text-gray-500">Belum upload</span>
              <?php endif; ?>
            </td>

            
            <td class="px-4 py-2 border">
              <a href="<?php echo e(route('admin.tickets.show', $t->id)); ?>" class="text-blue-600">Lihat</a> |
              <a href="<?php echo e(route('admin.tickets.edit', $t->id)); ?>" class="text-yellow-600">Edit</a>
              <span class="mx-1">|</span>
              <form action="<?php echo e(route('admin.tickets.destroy', $t->id)); ?>"
                    method="POST"
                    class="inline"
                    onsubmit="return confirm('Hapus ticket ini beserta semua dokumennya?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="text-red-600 hover:underline">Hapus</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="9" class="px-4 py-2 text-center text-gray-500">Belum ada ticket</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
    <div class="p-3">
  <?php echo e($tickets->onEachSide(1)->links()); ?>

</div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\webpenelitian\resources\views/admin/tickets/index.blade.php ENDPATH**/ ?>