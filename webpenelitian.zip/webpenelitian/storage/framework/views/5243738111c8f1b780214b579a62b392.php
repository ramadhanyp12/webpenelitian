

<?php $__env->startSection('title', 'Daftar Tickets'); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold mb-6">Daftar Tickets</h1>

  <?php if(session('success')): ?>
    <div class="bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded mb-4">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>

  <div class="mb-4">
    <a href="<?php echo e(route('tickets.create')); ?>" class="bg-green-600 text-white px-4 py-2 rounded">+ Buat Ticket</a>
  </div>

  <div class="overflow-x-auto bg-white shadow rounded">
    <table class="min-w-full border border-gray-300">
      <thead class="bg-gray-100">
        <tr>
          <th class="px-4 py-2 border">#</th>
          <th class="px-4 py-2 border">Judul Penelitian</th>
          <th class="px-4 py-2 border">Status</th>
          
          <th class="px-4 py-2 border">Surat Permohonan</th>
          <th class="px-4 py-2 border">Lampiran Permohonan</th>
          <th class="px-4 py-2 border">Surat Izin</th>
          <th class="px-4 py-2 border">Hasil Penelitian</th>
          <th class="px-4 py-2 border">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="border-t align-top">
            <td class="px-4 py-2 border"><?php echo e($loop->iteration); ?></td>
            <td class="px-4 py-2 border"><?php echo e($t->judul_penelitian); ?></td>

            
            <td class="px-4 py-2 border">
              <?php if($t->status === 'ditolak' && filled($t->alasan_ditolak)): ?>
                <span class="inline-block rounded border border-red-300 bg-red-50 text-red-700 text-xs px-2 py-1">
                  Ditolak: <?php echo e($t->alasan_ditolak); ?>

                </span>
              <?php else: ?>
                <?php
                  $classes = [
                    'dikirim'                => 'bg-gray-100 text-gray-700',
                    'menunggu_persetujuan'   => 'bg-yellow-100 text-yellow-700',
                    'disetujui'              => 'bg-blue-100 text-blue-700',
                    'ditolak'                => 'bg-red-100 text-red-700',
                    'menunggu_hasil'         => 'bg-amber-100 text-amber-700',
                    'selesai'                => 'bg-green-100 text-green-700',
                  ];
                ?>
                <span class="px-2 py-1 rounded text-sm <?php echo e($classes[$t->status] ?? 'bg-gray-100 text-gray-700'); ?>">
                  <?php echo e($t->status); ?>

                </span>
              <?php endif; ?>
            </td>

            
            <td class="px-4 py-2 border">
              <?php $surats = $t->suratDocuments; ?>
              <?php if($surats->count()): ?>
                <?php $__currentLoopData = $surats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div>
                    <a href="<?php echo e(asset('storage/'.$doc->file_path)); ?>" target="_blank" class="text-blue-600 underline">
                      <?php echo e($doc->original_name); ?>

                    </a>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
                <span class="text-gray-500">-</span>
              <?php endif; ?>
            </td>

            
            <td class="px-4 py-2 border">
              <?php $lampirans = $t->lampiranDocuments; ?>
              <?php if($lampirans->count()): ?>
                <?php $__currentLoopData = $lampirans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div>
                    <a href="<?php echo e(asset('storage/'.$doc->file_path)); ?>" target="_blank" class="text-blue-600 underline">
                      <?php echo e($doc->original_name); ?>

                    </a>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
                <span class="text-gray-500">-</span>
              <?php endif; ?>
            </td>

            
            <td class="px-4 py-2 border">
              <?php if($t->hasil_pdf_path): ?>
                <a href="<?php echo e(asset('storage/'.$t->hasil_pdf_path)); ?>" target="_blank" class="text-blue-600 underline">
                  Surat Izin
                </a>
              <?php else: ?>
                <span class="text-gray-500">Belum ada</span>
              <?php endif; ?>
            </td>

            
            <td class="px-4 py-2 border">
              <?php if($t->hasil_penelitian_path): ?>
                <a href="<?php echo e(asset('storage/'.$t->hasil_penelitian_path)); ?>" target="_blank" class="text-blue-600 underline">
                  Hasil
                </a>

                
                <?php if(auth()->check() && auth()->id() === $t->user_id): ?>
                  <form action="<?php echo e(route('tickets.hasil.destroy', $t)); ?>" method="POST"
                        onsubmit="return confirm('Hapus file hasil penelitian?')" class="inline-block ml-2">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="text-red-600 underline text-sm">Hapus</button>
                  </form>
                <?php endif; ?>
              <?php else: ?>
                <?php if(auth()->check() && auth()->id() === $t->user_id && $t->status === 'menunggu_hasil'): ?>
                  <form action="<?php echo e(route('tickets.hasil.upload', $t)); ?>" method="POST" enctype="multipart/form-data" class="flex items-center gap-2">
                    <?php echo csrf_field(); ?>
                    <input type="file" name="hasil" accept="application/pdf" required class="text-sm">
                    <button class="px-2 py-1 rounded bg-indigo-600 text-white text-xs">Upload</button>
                  </form>
                  <p class="text-gray-500 text-xs mt-1">Setelah upload, status tetap <b>menunggu_hasil</b> sampai diverifikasi admin.</p>
                <?php else: ?>
                  <span class="text-gray-500">Belum upload</span>
                <?php endif; ?>
              <?php endif; ?>
            </td>

            
            <td class="px-4 py-2 border">
              <a href="<?php echo e(route('tickets.show', $t->id)); ?>" class="text-blue-600">Lihat</a> |
              <a href="<?php echo e(route('tickets.edit', $t->id)); ?>" class="text-yellow-600">Edit</a>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="8" class="px-4 py-2 text-center text-gray-500">Belum ada ticket</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\webpenelitian\resources\views/tickets/index.blade.php ENDPATH**/ ?>