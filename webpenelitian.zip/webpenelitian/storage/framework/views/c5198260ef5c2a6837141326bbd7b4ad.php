

<?php $__env->startSection('title', 'Detail Ticket (Admin)'); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold mb-6">Detail Ticket #<?php echo e($ticket->id); ?></h1>

  <div class="bg-white shadow rounded p-6 space-y-4">
    <div>
      <span class="font-semibold">Nama:</span>
      <span><?php echo e($ticket->nama); ?></span>
    </div>
    <div>
      <span class="font-semibold">NIM:</span>
      <span><?php echo e($ticket->nim); ?></span>
    </div>
    <div>
      <span class="font-semibold">Program Studi:</span>
      <span><?php echo e($ticket->program_studi); ?></span>
    </div>
    <div>
      <span class="font-semibold">Kampus:</span>
      <span><?php echo e($ticket->kampus); ?></span>
    </div>
    <div>
      <span class="font-semibold">Tahun Ajaran:</span>
      <span><?php echo e($ticket->tahun_ajaran); ?></span>
    </div>
    <div>
      <span class="font-semibold">Judul Penelitian:</span>
      <span><?php echo e($ticket->judul_penelitian); ?></span>
    </div>
    <div>
      <span class="font-semibold">Keterangan:</span>
      <span><?php echo e($ticket->keterangan ?? '-'); ?></span>
    </div>
    <div>
      <span class="font-semibold">Lokasi Pengadilan:</span>
      <span><?php echo e($ticket->lokasi_pengadilan ?? '-'); ?></span>
    </div>
    <div>
      <span class="font-semibold">Status:</span>
      <span class="px-2 py-1 rounded bg-gray-200"><?php echo e($ticket->status); ?></span>
    </div>

    
    <div>
      <h2 class="font-semibold mb-2">Surat</h2>
      <?php if($ticket->suratDocuments->count()): ?>
        <ul class="list-disc ml-5 space-y-1">
          <?php $__currentLoopData = $ticket->suratDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <a href="<?php echo e(asset('storage/'.$doc->file_path)); ?>" target="_blank" class="text-blue-600 underline">
                <?php echo e($doc->original_name); ?>

              </a>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      <?php else: ?>
        <div class="text-sm text-gray-500">Belum ada file surat.</div>
      <?php endif; ?>
    </div>

    
    <div>
      <h2 class="font-semibold mb-2">Lampiran</h2>
      <?php if($ticket->lampiranDocuments->count()): ?>
        <ul class="list-disc ml-5 space-y-1">
          <?php $__currentLoopData = $ticket->lampiranDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <a href="<?php echo e(asset('storage/'.$doc->file_path)); ?>" target="_blank" class="text-blue-600 underline">
                <?php echo e($doc->original_name); ?>

              </a>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      <?php else: ?>
        <div class="text-sm text-gray-500">Belum ada file lampiran.</div>
      <?php endif; ?>
    </div>

    <div class="pt-4">
      <a href="<?php echo e(route('admin.tickets.edit', $ticket->id)); ?>" class="bg-yellow-500 text-white px-4 py-2 rounded">Edit</a>
      <form action="<?php echo e(route('admin.tickets.destroy', $ticket->id)); ?>"
        method="POST"
        class="inline"
        onsubmit="return confirm('Yakin hapus Ticket #<?php echo e($ticket->id); ?> beserta semua dokumennya?');">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded">Hapus</button>
  </form>
      <a href="<?php echo e(route('admin.tickets.index')); ?>" class="px-4 py-2 rounded border">Kembali</a>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\webpenelitian\resources\views/admin/tickets/show.blade.php ENDPATH**/ ?>