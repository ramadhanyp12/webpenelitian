

<?php $__env->startSection('title', 'Edit Ticket (Admin)'); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold mb-6">Edit Ticket #<?php echo e($ticket->id); ?></h1>

  <?php if(session('success')): ?>
    <div class="bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded mb-4">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
    <div class="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded mb-4">
      <ul class="list-disc ml-5">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($e); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  
  <div class="space-y-4 mb-6">
    <div class="border rounded p-3">
      <div class="font-semibold mb-2">Surat permohonan saat ini (<?php echo e($ticket->suratDocuments()->count()); ?>)</div>
      <?php if($ticket->suratDocuments()->count()): ?>
        <ul class="list-disc ml-5 space-y-1">
          <?php $__currentLoopData = $ticket->suratDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="flex items-center gap-2">
              <a href="<?php echo e(asset('storage/'.$doc->file_path)); ?>" target="_blank" class="text-blue-600 underline">
                <?php echo e($doc->original_name); ?>

              </a>
              
              <form action="<?php echo e(route('admin.tickets.documents.destroy', [$ticket->id, $doc->id])); ?>"
                    method="POST" onsubmit="return confirm('Hapus dokumen ini?');" class="inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="text-red-600 hover:underline">Hapus</button>
              </form>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      <?php else: ?>
        <div class="text-sm text-gray-500">Belum ada file.</div>
      <?php endif; ?>
    </div>

    <div class="border rounded p-3">
      <div class="font-semibold mb-2">Lampiran permohonan saat ini (<?php echo e($ticket->lampiranDocuments()->count()); ?>)</div>
      <?php if($ticket->lampiranDocuments()->count()): ?>
        <ul class="list-disc ml-5 space-y-1">
          <?php $__currentLoopData = $ticket->lampiranDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="flex items-center gap-2">
              <a href="<?php echo e(asset('storage/'.$doc->file_path)); ?>" target="_blank" class="text-blue-600 underline">
                <?php echo e($doc->original_name); ?>

              </a>
              
              <form action="<?php echo e(route('admin.tickets.documents.destroy', [$ticket->id, $doc->id])); ?>"
                    method="POST" onsubmit="return confirm('Hapus dokumen ini?');" class="inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="text-red-600 hover:underline">Hapus</button>
              </form>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      <?php else: ?>
        <div class="text-sm text-gray-500">Belum ada file.</div>
      <?php endif; ?>
    </div>
  </div>


<?php
  $suratPath = $ticket->surat_izin_pdf_path ?: $ticket->hasil_pdf_path;   // path yg ditampilkan
  $suratCol  = $ticket->surat_izin_pdf_path ? 'surat_izin_pdf_path'
             : ($ticket->hasil_pdf_path ? 'hasil_pdf_path' : null);       // nama kolom yg dihapus
?>

<div class="mb-4">
  <div class="font-semibold">
    Surat Izin <?php echo e($ticket->surat_izin_pdf_path ? '' : '(data lama)'); ?>

  </div>

  <?php if($suratPath): ?>
    <a href="<?php echo e(asset('storage/'.$suratPath)); ?>" target="_blank" class="text-blue-600 underline">
      Lihat
    </a>

    <form action="<?php echo e(route('admin.tickets.suratizin.destroy', $ticket->id)); ?>"
          method="POST" class="inline ml-2"
          onsubmit="return confirm('Hapus file Surat Izin ini?');">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <input type="hidden" name="col" value="<?php echo e($suratCol); ?>">
      <button class="text-red-600 hover:underline">Hapus</button>
    </form>
  <?php else: ?>
    <div class="text-gray-500">Belum ada file Surat Izin.</div>
  <?php endif; ?>
</div>

  
<div class="mb-6">
  <div class="font-semibold mb-2">Hasil Penelitian saat ini</div>
  <?php if($ticket->hasil_pdf_path): ?>
    <div class="flex items-center gap-3">
      <a href="<?php echo e(asset('storage/'.$ticket->hasil_pdf_path)); ?>"
         target="_blank"
         class="text-blue-600 underline">
        Lihat Hasil
      </a>

      <form action="<?php echo e(route('admin.tickets.hasil.destroy', $ticket->id)); ?>"
            method="POST"
            onsubmit="return confirm('Hapus file Hasil Penelitian ini?');"
            class="inline">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="text-red-600 hover:underline">Hapus</button>
      </form>
    </div>
  <?php else: ?>
    <div class="text-gray-500">Belum ada file Hasil Penelitian.</div>
  <?php endif; ?>
</div>

  
  <form action="<?php echo e(route('admin.tickets.update', $ticket->id)); ?>" method="POST" enctype="multipart/form-data" class="space-y-5 max-w-xl">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div>
      <label class="block mb-1 font-medium">Judul Penelitian</label>
      <input type="text" name="judul_penelitian" value="<?php echo e(old('judul_penelitian', $ticket->judul_penelitian)); ?>"
             class="w-full border rounded px-3 py-2" required>
    </div>

    <div>
      <label class="block mb-1 font-medium">Status</label>
<select name="status" class="w-full border rounded px-3 py-2">
  <?php $__currentLoopData = ['dikirim', 'menunggu_persetujuan', 'disetujui', 'ditolak', 'menunggu_hasil', 'selesai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($s); ?>" <?php if(old('status', $ticket->status) === $s): echo 'selected'; endif; ?>><?php echo e($s); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
    </div>

    <div>
      <label class="block mb-1 font-medium">Tambah Surat permohonan baru (PDF, bisa lebih dari satu, max 20MB/file)</label>
      <input type="file" name="surat_files[]" accept="application/pdf" class="w-full border rounded px-3 py-2" multiple>
    </div>

    <div>
      <label class="block mb-1 font-medium">Tambah Lampiran permohonan baru (PDF, bisa lebih dari satu, max 20MB/file)</label>
      <input type="file" name="lampiran_files[]" accept="application/pdf" class="w-full border rounded px-3 py-2" multiple>
    </div>

    <div>
      <label class="block mb-1 font-medium">Upload Surat Izin (PDF, max 20MB)</label>
      <input type="file" name="hasil_pdf" accept="application/pdf" class="w-full border rounded px-3 py-2">
      <?php if($ticket->hasil_pdf_path): ?>
        <p class="text-sm mt-1">
          File saat ini:
          <a href="<?php echo e(asset('storage/'.$ticket->hasil_pdf_path)); ?>" target="_blank" class="text-blue-600 underline">Lihat / unduh</a>
        </p>
      <?php endif; ?>
    </div>

    <div class="pt-2 flex gap-3">
      <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Simpan</button>
      <a href="<?php echo e(route('admin.tickets.index')); ?>" class="px-4 py-2 rounded border">Batal</a>
    </div>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\webpenelitian\resources\views/admin/tickets/edit.blade.php ENDPATH**/ ?>