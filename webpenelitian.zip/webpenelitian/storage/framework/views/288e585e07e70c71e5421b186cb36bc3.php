

<?php $__env->startSection('title','Upload Surat Izin TTD Digital'); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold mb-6">Upload Surat Izin yang Sudah Ditandatangani</h1>

  <?php if($errors->any()): ?>
    <div class="bg-red-100 text-red-800 border border-red-300 p-3 rounded mb-4">
      <ul class="list-disc ml-5">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($e); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  <div class="bg-white shadow rounded p-5 max-w-xl">
    <div class="mb-4">
      <div><span class="font-semibold">User:</span> <?php echo e($approval->ticket->user->name ?? '-'); ?></div>
      <div><span class="font-semibold">No. Surat:</span> <?php echo e($approval->nomor_surat); ?></div>
      <div><span class="font-semibold">Judul:</span> <?php echo e($approval->judul_penelitian); ?></div>
    </div>

    <form action="<?php echo e(route('admin.approvals.release.store', $approval->id)); ?>" method="POST" enctype="multipart/form-data" class="space-y-4">
      <?php echo csrf_field(); ?>

      <div>
        <label class="block mb-1 font-medium">File PDF yang sudah ditandatangani (TTD digital)</label>
        <input type="file" name="signed_pdf" accept="application/pdf" class="w-full border rounded px-3 py-2" required>
        <p class="text-sm text-gray-500 mt-1">Format: PDF, maks 20 MB.</p>
      </div>

      <label class="inline-flex items-center gap-2">
        <input type="checkbox" name="released_to_user" value="1" checked>
        <span>Rilis ke user sekarang (status tiket → <em>menunggu_hasil</em> & kirim notifikasi)</span>
      </label>

      <div class="pt-2 flex gap-3">
        <button class="bg-blue-600 text-white px-4 py-2 rounded">Upload</button>
        <a href="<?php echo e(route('admin.approvals.index')); ?>" class="px-4 py-2 rounded border">Batal</a>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\webpenelitian\resources\views/admin/approvals/release.blade.php ENDPATH**/ ?>