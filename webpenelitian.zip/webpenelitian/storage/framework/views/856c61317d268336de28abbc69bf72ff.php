

<?php $__env->startSection('title','Edit Approval'); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold mb-6">
    Edit Approval – Ticket #<?php echo e($approval->ticket->id); ?> (<?php echo e($approval->ticket->user->name); ?>)
  </h1>

  <?php if(session('success')): ?>
    <div class="bg-green-100 text-green-800 border border-green-300 p-3 rounded mb-4"><?php echo e(session('success')); ?></div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
    <div class="bg-red-100 border border-red-300 text-red-800 px-4 py-3 rounded mb-4">
      <ul class="list-disc ml-5">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($e); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  <form action="<?php echo e(route('admin.approvals.update', $approval->id)); ?>" method="POST" enctype="multipart/form-data" class="space-y-5 max-w-2xl">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <label class="block mb-1 font-medium">Nama Mahasiswa</label>
        <input name="nama_mahasiswa" class="w-full border rounded px-3 py-2" value="<?php echo e(old('nama_mahasiswa', $approval->nama_mahasiswa)); ?>" required>
      </div>
      <div>
        <label class="block mb-1 font-medium">NIM</label>
        <input name="nim_mahasiswa" class="w-full border rounded px-3 py-2" value="<?php echo e(old('nim_mahasiswa', $approval->nim_mahasiswa)); ?>" required>
      </div>
      <div>
        <label class="block mb-1 font-medium">Program Studi</label>
        <input name="prodi_mahasiswa" class="w-full border rounded px-3 py-2" value="<?php echo e(old('prodi_mahasiswa', $approval->prodi_mahasiswa)); ?>" required>
      </div>
      <div>
        <label class="block mb-1 font-medium">Judul Penelitian</label>
        <input name="judul_penelitian" class="w-full border rounded px-3 py-2" value="<?php echo e(old('judul_penelitian', $approval->judul_penelitian)); ?>" required>
      </div>
    </div>

    <hr class="my-2">

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <label class="block mb-1 font-medium">Nama Penandatangan</label>
        <input name="nama_penandatangan" class="w-full border rounded px-3 py-2" value="<?php echo e(old('nama_penandatangan', $approval->nama_penandatangan)); ?>" required>
      </div>
      <div>
        <label class="block mb-1 font-medium">NIP Penandatangan</label>
        <input name="nip_penandatangan" class="w-full border rounded px-3 py-2" value="<?php echo e(old('nip_penandatangan', $approval->nip_penandatangan)); ?>" required>
      </div>
      <div>
        <label class="block mb-1 font-medium">Pangkat/Gol</label>
        <input name="pangkat_gol" class="w-full border rounded px-3 py-2" value="<?php echo e(old('pangkat_gol', $approval->pangkat_gol)); ?>">
      </div>
      <div>
        <label class="block mb-1 font-medium">Jabatan Penandatangan</label>
        <input name="jabatan_penandatangan" class="w-full border rounded px-3 py-2" value="<?php echo e(old('jabatan_penandatangan', $approval->jabatan_penandatangan)); ?>">
      </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <label class="block mb-1 font-medium">Nomor Surat</label>
        <input name="nomor_surat" class="w-full border rounded px-3 py-2" value="<?php echo e(old('nomor_surat', $approval->nomor_surat)); ?>" required>
      </div>
      <?php $__errorArgs = ['nomor_surat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <div class="text-red-600 text-sm mt-1"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <div>
        <label class="block mb-1 font-medium">Tanggal Surat</label>
        <input type="date" name="tanggal_surat" class="w-full border rounded px-3 py-2" value="<?php echo e(old('tanggal_surat', optional($approval->tanggal_surat)->format('Y-m-d'))); ?>" required>
      </div>
      <div class="md:col-span-2">
        <label class="block mb-1 font-medium">Tujuan (Kepada Yth.)</label>
        <input name="tujuan" class="w-full border rounded px-3 py-2" value="<?php echo e(old('tujuan', $approval->tujuan)); ?>" required>
      </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <label class="block mb-1 font-medium">Upload Tanda Tangan (png/jpg)</label>
        <input type="file" name="ttd" accept=".png,.jpg,.jpeg" class="w-full border rounded px-3 py-2">
        <?php if($approval->ttd_path): ?>
          <div class="text-sm mt-1">Saat ini: <span class="text-gray-600"><?php echo e($approval->ttd_path); ?></span></div>
        <?php endif; ?>
      </div>
      <div>
        <label class="block mb-1 font-medium">Upload Stempel (png/jpg)</label>
        <input type="file" name="stempel" accept=".png,.jpg,.jpeg" class="w-full border rounded px-3 py-2">
        <?php if($approval->stempel_path): ?>
          <div class="text-sm mt-1">Saat ini: <span class="text-gray-600"><?php echo e($approval->stempel_path); ?></span></div>
        <?php endif; ?>
      </div>
    </div>

    <?php if($approval->generated_pdf_path): ?>
      <div class="text-sm">
        <span class="font-medium">PDF Terbuat:</span>
        <a href="<?php echo e(asset('storage/'.$approval->generated_pdf_path)); ?>" target="_blank" class="text-blue-600 underline">Lihat / unduh</a>
      </div>
    <?php endif; ?>

    <div class="flex flex-wrap items-center gap-3 pt-2">
      <button class="bg-blue-600 text-white px-4 py-2 rounded">Simpan</button>

      <form action="<?php echo e(route('admin.approvals.generatePdf', $approval->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button class="bg-indigo-600 text-white px-4 py-2 rounded">Generate PDF</button>
      </form>

      <a href="<?php echo e(route('admin.approvals.index')); ?>" class="px-4 py-2 rounded border">Kembali</a>
    </div>
  </form>

  
  <div class="max-w-2xl mt-6 p-4 border rounded bg-red-50">
    <h3 class="font-semibold text-red-700 mb-2">Tolak Tiket ini</h3>
    <form action="<?php echo e(route('admin.approvals.deny', $approval->ticket_id)); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <textarea name="alasan_ditolak" rows="3" class="w-full border rounded px-3 py-2"
                placeholder="Tulis alasan penolakan" required></textarea>
      <div class="mt-2">
        <button class="px-3 py-1 bg-red-700 text-white rounded">Kirim Penolakan</button>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\webpenelitian\resources\views/admin/approvals/edit.blade.php ENDPATH**/ ?>