<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold">Halo <?php echo e(Auth::user()->name); ?></h1>
    <p>Anda login sebagai <strong><?php echo e(Auth::user()->role); ?></strong></p>
    <br><br>
    <h2 class="text-xl font-semibold mb-3">🎥 Tutorial Penggunaan Website User</h2>
    <div class="w-full max-w-3xl mx-auto">
  <div class="relative pt-[56.25%] overflow-hidden rounded-[12px] shadow">
    <iframe
      class="absolute inset-0 w-full h-full"
      src="https://www.youtube-nocookie.com/embed/XZPT0udVUVk?rel=0&modestbranding=1"
      title="Tutorial Penggunaan Website User"
      loading="lazy"
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
      referrerpolicy="strict-origin-when-cross-origin"
      allowfullscreen>
    </iframe>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make(Auth::user()->role === 'admin' ? 'layouts.admin' : 'layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\webpenelitian\resources\views/dashboard.blade.php ENDPATH**/ ?>