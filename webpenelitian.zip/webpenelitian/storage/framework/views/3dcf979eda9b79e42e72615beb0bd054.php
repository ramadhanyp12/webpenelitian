

<?php $__env->startSection('title', 'Detail Ticket #'.$ticket->id); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold mb-6">Detail Ticket</h1>

  <div class="bg-white rounded shadow p-4 mb-6">
    <div class="grid md:grid-cols-2 gap-4">
      <div><strong>ID:</strong> <?php echo e($ticket->id); ?></div>
      <div><strong>Nama:</strong> <?php echo e($ticket->nama); ?></div>
      <div><strong>NIM:</strong> <?php echo e($ticket->nim); ?></div>
      <div><strong>Program Studi:</strong> <?php echo e($ticket->program_studi); ?></div>
      <div><strong>Kampus:</strong> <?php echo e($ticket->kampus); ?></div>
      <div><strong>Tahun Ajaran:</strong> <?php echo e($ticket->tahun_ajaran); ?></div>
      <div class="md:col-span-2"><strong>Judul Penelitian:</strong> <?php echo e($ticket->judul_penelitian); ?></div>
      <p><strong>Lokasi Pengadilan:</strong> <?php echo e($ticket->lokasi_pengadilan ?: '-'); ?></p>
      <div class="md:col-span-2"><strong>Status:</strong> <?php echo e($ticket->status); ?></div>
      <div class="mt-6">
  <h3 class="font-semibold mb-2">Keterangan (File yang diminta apa saja tulis disini)</h3>
  <div class="border rounded px-4 py-3 bg-white">
    <?php echo nl2br(e($ticket->keterangan ?: 'Tidak ada keterangan')); ?>

  </div>
</div>
      <?php if($ticket->status === 'ditolak' && $ticket->alasan_ditolak): ?>
        <div class="md:col-span-2">
          <span class="inline-block bg-red-100 text-red-700 border border-red-300 px-3 py-1 rounded">
            Ditolak: <?php echo e($ticket->alasan_ditolak); ?>

          </span>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="bg-white rounded shadow p-4">
    <h2 class="text-lg font-semibold mb-3">Dokumen</h2>

    
    <div class="mb-3">
      <div class="font-medium">Surat Permohonan:</div>
      <?php if($ticket->suratDocuments->count()): ?>
        <ul class="list-disc ml-5">
          <?php $__currentLoopData = $ticket->suratDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <a href="<?php echo e(asset('storage/'.$doc->file_path)); ?>" target="_blank" class="text-blue-600 underline">
                <?php echo e($doc->original_name); ?>

              </a>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      <?php else: ?>
        <div class="text-gray-500">Tidak ada surat</div>
      <?php endif; ?>
    </div>

    
    <div class="mb-3">
      <div class="font-medium">Lampiran Permohonan:</div>
      <?php if($ticket->lampiranDocuments->count()): ?>
        <ul class="list-disc ml-5">
          <?php $__currentLoopData = $ticket->lampiranDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <a href="<?php echo e(asset('storage/'.$doc->file_path)); ?>" target="_blank" class="text-blue-600 underline">
                <?php echo e($doc->original_name); ?>

              </a>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      <?php else: ?>
        <div class="text-gray-500">Tidak ada lampiran</div>
      <?php endif; ?>
    </div>

    
<div>
  <div class="font-medium">Surat Izin:</div>

  <?php if($ticket->status === 'menunggu_hasil' && $ticket->hasil_pdf_path): ?>
    <a href="<?php echo e(asset('storage/'.$ticket->hasil_pdf_path)); ?>" target="_blank" class="text-blue-600 underline">
      Lihat Surat Izin (PDF)
    </a>
  <?php elseif($ticket->status === 'disetujui'): ?>
    <div class="text-gray-500">
      Disetujui. Menunggu admin merilis PDF bertanda tangan digital.
    </div>
  <?php else: ?>
    <div class="text-gray-500">Belum ada hasil</div>
  <?php endif; ?>
</div>

  <div class="mt-4 flex gap-3">
    <a href="<?php echo e(route('tickets.index')); ?>" class="px-4 py-2 rounded border">← Kembali</a>
    <a href="<?php echo e(route('tickets.edit', $ticket->id)); ?>" class="px-4 py-2 rounded bg-blue-600 text-white">Edit Ticket</a>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\webpenelitian\resources\views/tickets/show.blade.php ENDPATH**/ ?>