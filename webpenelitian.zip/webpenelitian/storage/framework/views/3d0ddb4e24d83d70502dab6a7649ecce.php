

<?php $__env->startSection('title', 'Detail User'); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="text-2xl font-bold mb-6">Detail User</h1>

  <div class="bg-white shadow rounded p-5 space-y-2">
    <div><span class="font-semibold">Nama:</span> <?php echo e($user->name); ?></div>
    <div><span class="font-semibold">Email:</span> <?php echo e($user->email); ?></div>
    <div><span class="font-semibold">Role:</span> <?php echo e($user->role ?? '-'); ?></div>
    <div><span class="font-semibold">NIM:</span> <?php echo e(optional($user->profile)->nim ?? '-'); ?></div>
    <div><span class="font-semibold">Program Studi:</span> <?php echo e(optional($user->profile)->program_studi ?? '-'); ?></div>
    <div><span class="font-semibold">Asal Kampus:</span> <?php echo e(optional($user->profile)->kampus ?? '-'); ?></div>
    <div><span class="font-semibold">Tahun Ajaran:</span> <?php echo e(optional($user->profile)->tahun_ajaran ?? '-'); ?></div>
  </div>

  <h2 class="text-xl font-semibold mt-8 mb-3">Ticket User</h2>
  <div class="bg-white shadow rounded overflow-x-auto">
    <table class="min-w-full border">
      <thead class="bg-gray-100">
        <tr>
          <th class="px-4 py-2 border">#</th>
          <th class="px-4 py-2 border">Judul</th>
          <th class="px-4 py-2 border">Status</th>
          <th class="px-4 py-2 border">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $user->tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td class="px-4 py-2 border"><?php echo e($loop->iteration); ?></td>
            <td class="px-4 py-2 border"><?php echo e($t->judul_penelitian); ?></td>
            <td class="px-4 py-2 border"><?php echo e($t->status); ?></td>
            <td class="px-4 py-2 border">
              <a href="<?php echo e(route('admin.tickets.show', $t->id)); ?>" class="text-blue-600">Lihat</a> |
              <a href="<?php echo e(route('admin.tickets.edit', $t->id)); ?>" class="text-yellow-600">Edit</a>
              
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="4" class="px-4 py-3 text-center text-gray-500">Belum ada ticket</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <div class="mt-4">
    <a href="<?php echo e(route('admin.users.index')); ?>" class="px-4 py-2 rounded border">Kembali</a>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\webpenelitian\resources\views/admin/users/show.blade.php ENDPATH**/ ?>