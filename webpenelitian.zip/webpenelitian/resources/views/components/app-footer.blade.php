<footer class="mt-auto bg-gray-100 border-t text-sm text-gray-600">
  <div class="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
    <div>© {{ date('Y') }} Web Penelitian. All rights reserved.</div>
    <div>
      WhatsApp:
      <a class="text-green-600 hover:underline"
         href="https://wa.me/6282145667305" target="_blank" rel="noopener">
        082145667305
      </a>
    </div>
  </div>
</footer>
